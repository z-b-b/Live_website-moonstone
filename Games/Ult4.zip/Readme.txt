                ULTIMA IV - PC GAMES VERSION

RUNNING ULTIMA IV IN MS-DOS

     Ultima IV will run under most memory configurations  in
MS-DOS.  The  following steps will start the game  once  you
arrive at a MS-DOS prompt. If you have Windows 3.1, exit  to
MS-DOS.  To do this LEFT-CLICK on the FILE menu option,  and
then  LEFT-CLICK on Exit. If you have Windows 95,  refer  to
the next section "Running Ultima IV In Windows 95".

     Run Through MS-DOS

     1)   Type "C:" and hit "ENTER".
     2)   Type "CD\ULTIMA4" and hit "ENTER".
     3)   Type "ULTIMA" and hit "ENTER".

     This will begin the game.

     The  only way to exit Ultima IV from true MS-DOS is  to
reboot  the computer. Pressing "CTRL-ALT-DELETE" will  cause
the  system  to restart. NOTE: Make sure to save  your  game
using the "Q" key prior to exiting Ultima IV.
     
     If  the  game  runs  too fast your best  option  is  to
download  MOSLO. This utility will permit you  to  set  your
processor  speed to a lower clock rate, making this  classic
title  much more enjoyable. It is available on the  Internet
at http://www.origin.ea.com/tech/download.html.Documentation 
on it's usage is included with the program.

RUNNING ULTIMA IV IN WINDOWS 95

     Ultima IV will run under Windows 95 in MS-DOS Emulation
mode.  The  following steps will start  the  game  once  you
arrive on the Windows 95 desktop. If you have Windows 3.1 or
only  MS-DOS, refer to the section on "Running Ultima IV  In
MS-DOS".

     Run Through Windows 95

     1)    DOUBLE LEFT-CLICK on the MY COMPUTER ICON on  the
       desktop.
     2)   DOUBLE LEFT-CLICK on the HARD DRIVE (C: ) ICON within
       the MY COMPUTER window.
     3)   DOUBLE LEFT-CLICK on the ULTIMA4 folder within the HARD
       DRIVE (C: ) window.
4)   DOUBLE LEFT-CLICK  on the ULTIMA icon within the
ULTIMA4 window.

     This will begin the game

     You  will  need to end the MS-DOS session in  order  to
exit  Ultima IV. If you are running Ultima IV in Full Screen
mode, press CTRL-ALT-DELETE on the keyboard. This will bring
up  the  Windows 95 CLOSE PROGRAM window. LEFT-CLICK on  the
Ultima IV line in this window and then LEFT-CLICK on the END
TASK button. If running Ultima IV in a window, left-click on
the  X  icon located in the upper left corner of the screen.
NOTE: Make sure to save your game using the "Q" key prior to
exiting Ultima IV.

     If  you  find  that  Ultima IV runs  too  fast,  it  is
recommended  that you play it in a window  instead  of  full
screen.  Hit  "ALT-ENTER"  on the  keyboard  after  starting
Ultima  IV to do this. If the game continues runs  too  fast
your  best  option is to download MOSLO. This  utility  will
permit  you  to  set your processor speed to a  lower  clock
rate,  making this classic title much more enjoyable. It  is
available         on         the         Internet         at
http://www.origin.ea.com/tech/download.html.   Documentation
on it's usage is included with the program.

DOCUMENTATION

     Ultima  IV  is  a  complex game. We have  provided  the
necessary  information that will allow you  to  fully  enjoy
this classic title. It has been broken into 4 sections:

The  History of Britannia: For MS-DOS or Windows 3.1  users,
the  file is HISTORY.TXT. For Windows 95 users the  file  is
THE  HISTORY  OF  BRITANNIA.DOC. This file  contains  useful
background information on the world of Ultima IV.

The  Book of Mystic Wisdom: For MS-DOS or Windows 3.1 users,
the file is WISDOM.TXT. For Windows 95 users the file is THE
BOOK OF MYSTIC WISDOM.DOC. This file outlines the spells and
reagents used in Ultima IV.

Keyboard  Reference: For MS-DOS or Windows  3.1  users,  the
file  is  KEYBOARD.TXT. For Windows 95  users  the  file  is
KEYBOARD   REFERENCE.DOC.  This  file  details  the   actual
keyboard commands used in playing Ultima IV.

Hints:  For  MS-DOS  or  Windows  3.1  users,  the  file  is
HINTS.TXT. For Windows 95 users, the file is HINTS.DOC. This
file  give  information on completing  the  many  quests  of
Ultima IV.

Map:  A  version  of  the cloth map that  shipped  with  the
original  game  is  represented as  a  BMP  file.  Use  your
favorite graphics display program to show this image.
